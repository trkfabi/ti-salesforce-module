//
//  SCSSelfServiceAction.h
//  ServiceCommon
//
//  Created by Michael Nachbaur on 3/17/16.
//  Copyright © 2016 Salesforce.com. All rights reserved.
//

@import SalesforceCore.SalesforceNetwork;

@interface SCSSelfServiceAction : SFCSalesforceAction

- (NSString*)mockFileName;

@end
