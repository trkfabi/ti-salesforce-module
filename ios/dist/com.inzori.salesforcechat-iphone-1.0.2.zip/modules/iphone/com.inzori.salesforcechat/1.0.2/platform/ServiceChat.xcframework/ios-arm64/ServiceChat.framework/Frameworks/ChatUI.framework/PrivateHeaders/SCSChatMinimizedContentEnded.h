//
//  SCSChatMinimizedContentEnded.h
//  ChatUI
//
//  Created by Michael Nachbaur on 9/6/17.
//  Copyright © 2017 Salesforce.com. All rights reserved.
//

#import "SCSChatMinimizedContent.h"

NS_ASSUME_NONNULL_BEGIN

@interface SCSChatMinimizedContentEnded : SCSChatMinimizedContent

@end

NS_ASSUME_NONNULL_END
