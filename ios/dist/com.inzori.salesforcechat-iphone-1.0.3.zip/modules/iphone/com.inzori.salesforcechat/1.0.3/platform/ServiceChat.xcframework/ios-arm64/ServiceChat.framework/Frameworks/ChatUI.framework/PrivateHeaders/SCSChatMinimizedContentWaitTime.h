//
//  SCSChatMinimizedContentWaitTime.h
//  ChatUI
//
//  Created by Michael Nachbaur on 7/11/19.
//  Copyright © 2019 Salesforce.com. All rights reserved.
//

#import "SCSChatMinimizedContentQueuePosition.h"

NS_ASSUME_NONNULL_BEGIN

@interface SCSChatMinimizedContentWaitTime : SCSChatMinimizedContentQueuePosition

@end

NS_ASSUME_NONNULL_END
